﻿namespace Concurrent_forms
{
    partial class Levels
    {
        /// <summary>
        /// formularz okienkowy wyboru poziomu
        /// </summary>
        public System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Levels));
            this.level1_btn = new System.Windows.Forms.PictureBox();
            this.level8_btn = new System.Windows.Forms.PictureBox();
            this.level3_btn = new System.Windows.Forms.PictureBox();
            this.level7_btn = new System.Windows.Forms.PictureBox();
            this.level6_btn = new System.Windows.Forms.PictureBox();
            this.level5_btn = new System.Windows.Forms.PictureBox();
            this.level2_btn = new System.Windows.Forms.PictureBox();
            this.level4_btn = new System.Windows.Forms.PictureBox();
            this.exit_btn = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.level1_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level8_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level3_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level7_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level6_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level5_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level2_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.level4_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_btn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // level1_btn
            // 
            this.level1_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl1_default;
            this.level1_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level1_btn.Location = new System.Drawing.Point(195, 182);
            this.level1_btn.Name = "level1_btn";
            this.level1_btn.Size = new System.Drawing.Size(153, 152);
            this.level1_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level1_btn.TabIndex = 0;
            this.level1_btn.TabStop = false;
            this.level1_btn.Click += new System.EventHandler(this.level1_btn_Click);
            this.level1_btn.MouseLeave += new System.EventHandler(this.level1_btn_MouseLeave);
            this.level1_btn.MouseHover += new System.EventHandler(this.level1_btn_MouseHover);
            // 
            // level8_btn
            // 
            this.level8_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl8_default;
            this.level8_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level8_btn.Location = new System.Drawing.Point(697, 349);
            this.level8_btn.Name = "level8_btn";
            this.level8_btn.Size = new System.Drawing.Size(142, 141);
            this.level8_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level8_btn.TabIndex = 1;
            this.level8_btn.TabStop = false;
            this.level8_btn.Click += new System.EventHandler(this.level8_btn_Click);
            this.level8_btn.MouseLeave += new System.EventHandler(this.level8_btn_MouseLeave);
            this.level8_btn.MouseHover += new System.EventHandler(this.level8_btn_MouseHover);
            // 
            // level3_btn
            // 
            this.level3_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl3_default;
            this.level3_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level3_btn.Location = new System.Drawing.Point(531, 182);
            this.level3_btn.Name = "level3_btn";
            this.level3_btn.Size = new System.Drawing.Size(148, 152);
            this.level3_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level3_btn.TabIndex = 2;
            this.level3_btn.TabStop = false;
            this.level3_btn.Click += new System.EventHandler(this.level3_btn_Click);
            this.level3_btn.MouseLeave += new System.EventHandler(this.level3_btn_MouseLeave);
            this.level3_btn.MouseHover += new System.EventHandler(this.level3_btn_MouseHover);
            // 
            // level7_btn
            // 
            this.level7_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl7_default;
            this.level7_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level7_btn.Location = new System.Drawing.Point(531, 349);
            this.level7_btn.Name = "level7_btn";
            this.level7_btn.Size = new System.Drawing.Size(148, 141);
            this.level7_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level7_btn.TabIndex = 3;
            this.level7_btn.TabStop = false;
            this.level7_btn.Click += new System.EventHandler(this.level7_btn_Click);
            this.level7_btn.MouseLeave += new System.EventHandler(this.level7_btn_MouseLeave);
            this.level7_btn.MouseHover += new System.EventHandler(this.level7_btn_MouseHover);
            // 
            // level6_btn
            // 
            this.level6_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl6_default;
            this.level6_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level6_btn.Location = new System.Drawing.Point(364, 349);
            this.level6_btn.Name = "level6_btn";
            this.level6_btn.Size = new System.Drawing.Size(148, 141);
            this.level6_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level6_btn.TabIndex = 4;
            this.level6_btn.TabStop = false;
            this.level6_btn.Click += new System.EventHandler(this.level6_btn_Click);
            this.level6_btn.MouseLeave += new System.EventHandler(this.level6_btn_MouseLeave);
            this.level6_btn.MouseHover += new System.EventHandler(this.level6_btn_MouseHover);
            // 
            // level5_btn
            // 
            this.level5_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl5_default;
            this.level5_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level5_btn.Location = new System.Drawing.Point(195, 349);
            this.level5_btn.Name = "level5_btn";
            this.level5_btn.Size = new System.Drawing.Size(153, 141);
            this.level5_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level5_btn.TabIndex = 5;
            this.level5_btn.TabStop = false;
            this.level5_btn.Click += new System.EventHandler(this.level5_btn_Click);
            this.level5_btn.MouseLeave += new System.EventHandler(this.level5_btn_MouseLeave);
            this.level5_btn.MouseHover += new System.EventHandler(this.level5_btn_MouseHover);
            // 
            // level2_btn
            // 
            this.level2_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl2_default;
            this.level2_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level2_btn.Location = new System.Drawing.Point(364, 182);
            this.level2_btn.Name = "level2_btn";
            this.level2_btn.Size = new System.Drawing.Size(148, 152);
            this.level2_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level2_btn.TabIndex = 6;
            this.level2_btn.TabStop = false;
            this.level2_btn.Click += new System.EventHandler(this.level2_btn_Click);
            this.level2_btn.MouseLeave += new System.EventHandler(this.level2_btn_MouseLeave);
            this.level2_btn.MouseHover += new System.EventHandler(this.level2_btn_MouseHover_1);
            // 
            // level4_btn
            // 
            this.level4_btn.BackgroundImage = global::Concurrent_forms.Properties.Resources.lvl4_default;
            this.level4_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.level4_btn.Location = new System.Drawing.Point(697, 182);
            this.level4_btn.Name = "level4_btn";
            this.level4_btn.Size = new System.Drawing.Size(142, 152);
            this.level4_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.level4_btn.TabIndex = 7;
            this.level4_btn.TabStop = false;
            this.level4_btn.Click += new System.EventHandler(this.level4_btn_Click);
            this.level4_btn.MouseLeave += new System.EventHandler(this.level4_btn_MouseLeave);
            this.level4_btn.MouseHover += new System.EventHandler(this.level4_btn_MouseHover);
            // 
            // exit_btn
            // 
            this.exit_btn.Image = global::Concurrent_forms.Properties.Resources.left_arr_default;
            this.exit_btn.Location = new System.Drawing.Point(26, 26);
            this.exit_btn.Name = "exit_btn";
            this.exit_btn.Size = new System.Drawing.Size(150, 150);
            this.exit_btn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exit_btn.TabIndex = 9;
            this.exit_btn.TabStop = false;
            this.exit_btn.Click += new System.EventHandler(this.exit_btn_Click);
            this.exit_btn.MouseEnter += new System.EventHandler(this.exit_btn_MouseEnter);
            this.exit_btn.MouseLeave += new System.EventHandler(this.exit_btn_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Concurrent_forms.Properties.Resources.bgcolor;
            this.pictureBox1.Location = new System.Drawing.Point(586, 520);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(216, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // Levels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.exit_btn);
            this.Controls.Add(this.level4_btn);
            this.Controls.Add(this.level2_btn);
            this.Controls.Add(this.level5_btn);
            this.Controls.Add(this.level6_btn);
            this.Controls.Add(this.level7_btn);
            this.Controls.Add(this.level3_btn);
            this.Controls.Add(this.level8_btn);
            this.Controls.Add(this.level1_btn);
            this.Name = "Levels";
            this.Text = "Levels";
            ((System.ComponentModel.ISupportInitialize)(this.level1_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level8_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level3_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level7_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level6_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level5_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level2_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.level4_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exit_btn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level1_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level8_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level3_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level7_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level6_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level5_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level2_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox level4_btn;
        /// <summary>
        /// przycisk przenoszący do wybranego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox exit_btn;
        /// <summary>
        /// pictureBox, element interfejsu graficznego
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox1;
    }
}