﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;

namespace Concurrent_forms
{
    public partial class main_menu : Form
    {
        /// <summary>
        /// tworzy odtwarzacz ścieżek wav
        /// </summary>
        /// <param name=player">Odtwarzacz multimediów z WMPLib</param>
        public static WMPLib.WindowsMediaPlayer player = new WMPLib.WindowsMediaPlayer();

        /// <summary>
        /// konstruktor klasy formularza
        /// </summary>
        public main_menu()
        {
            InitializeComponent();
            player.URL = "background_song.wav";
            player.controls.play();
            player.settings.volume = 25;
            player.settings.playCount = 3;
        }
        /// <summary>
        /// otwiera formularz wstępu 
        /// </summary>
        public void newgame_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Intro intro1 = new Intro();
            intro1.StartPosition = FormStartPosition.CenterScreen;
            intro1.ShowDialog();
        }
        /// <summary>
        /// animuje obraz i dźwięk najechania na przycisk
        /// </summary>
        public void newgame_btn_MouseHover(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click = new System.Media.SoundPlayer();
            click.SoundLocation = "clink.wav";
            click.Play();
            newgame_btn.Image = Properties.Resources.newgame_keyin; // Podświetlenie klawisza

        }
        /// <summary>
        /// animuje obraz i dźwięk najechania na przycisk
        /// </summary>
        public void levels_btn_MouseHover(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click = new System.Media.SoundPlayer();
            click.SoundLocation = "clink.wav";
            click.Play();
            levels_btn.Image = Properties.Resources.lvl_sel_keyin; // Podświetlenie klawisza
        }
        /// <summary>
        /// animuje obraz i dźwięk najechania na przycisk
        /// </summary>
        public void Exit_MouseHover(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click = new System.Media.SoundPlayer();
            click.SoundLocation = "clink.wav";
            click.Play();
            exit_btn.Image = Properties.Resources.exit_keyin; // Podświetlenie klawisza
        }
        /// <summary>
        /// przywraca domyślny wygląd przycisku
        /// </summary>
        public void newgame_btn_MouseLeave(object sender, EventArgs e)
        {
            newgame_btn.Image = Properties.Resources.newgame_default; // Zmiana podswietlenia klawisza
        }
        /// <summary>
        /// przywraca domyślny wygląd przycisku
        /// </summary>
        public void levels_btn_MouseLeave(object sender, EventArgs e)
        {
            levels_btn.Image = Properties.Resources.lvl_sel_default; // Zmiana podswietlenia klawisza
        }
        /// <summary>
        /// przywraca domyślny wygląd przycisku
        /// </summary>
        public void exit_btn_MouseLeave(object sender, EventArgs e)
        {
            exit_btn.Image = Properties.Resources.exit_default; // Zmiana podswietlenia klawisza
        }
        /// <summary>
        /// otwiera formularz wyboru poziomu
        /// </summary>
        public void levels_btn_MouseClick(object sender, MouseEventArgs e)
        {
            this.Hide();
            Levels poziomy = new Levels();
            poziomy.StartPosition = FormStartPosition.CenterScreen;
            poziomy.ShowDialog();
        }
        /// <summary>
        /// zamyka aplikację
        /// </summary>
        public void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        /// <summary>
        /// animuje obraz i dźwięk najechania na przycisk
        /// </summary>
        public void options_btn_MouseHover(object sender, EventArgs e)
        {
            System.Media.SoundPlayer click = new System.Media.SoundPlayer();
            click.SoundLocation = "clink.wav";
            click.Play();
            options_btn.Image = Properties.Resources.options_keyin; // Podświetlenie klawisza
        }
        /// <summary>
        /// przywraca domyślny wygląd przycisku
        /// </summary>
        public void options_btn_MouseLeave(object sender, EventArgs e)
        {
            options_btn.Image = Properties.Resources.options_default; // Zmiana podswietlenia klawisza
        }
        /// <summary>
        /// otwiera formularz opcji
        /// </summary>
        public void options_btn_MouseClick(object sender, MouseEventArgs e)
        {
            this.Hide();
            Options opcje = new Options();
            opcje.StartPosition = FormStartPosition.CenterScreen;
            opcje.ShowDialog();
            
        }
    }
}

