﻿namespace Concurrent_forms
{
    partial class Level5
    {
        /// <summary>
        /// formularz okienkowy poziomu
        /// </summary>
        public System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Level5));
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.slot1 = new System.Windows.Forms.PictureBox();
            this.toolbox = new System.Windows.Forms.PictureBox();
            this.infobox = new System.Windows.Forms.PictureBox();
            this.description = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.infobox_img = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.slot4 = new System.Windows.Forms.PictureBox();
            this.slot5 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.nextlvl = new System.Windows.Forms.PictureBox();
            this.victory = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolbox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infobox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.description)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infobox_img)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nextlvl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.victory)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Concurrent_forms.Properties.Resources.bipolar_transistor;
            this.pictureBox9.Location = new System.Drawing.Point(178, 611);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(89, 92);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 8;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "inductor_tag";
            this.pictureBox9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox9_MouseDown);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Concurrent_forms.Properties.Resources.capacitor;
            this.pictureBox8.Location = new System.Drawing.Point(109, 611);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(62, 96);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Tag = "capacitor_tag";
            this.pictureBox8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox8_MouseDown);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Concurrent_forms.Properties.Resources.resistor;
            this.pictureBox7.Location = new System.Drawing.Point(35, 611);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(66, 96);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "resistor_tag";
            this.pictureBox7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox7_MouseDown);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Concurrent_forms.Properties.Resources.check_default;
            this.pictureBox5.Location = new System.Drawing.Point(97, 26);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(239, 84);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            this.pictureBox5.MouseLeave += new System.EventHandler(this.pictureBox5_MouseLeave);
            this.pictureBox5.MouseHover += new System.EventHandler(this.pictureBox5_MouseHover);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Concurrent_forms.Properties.Resources.left_arr_default;
            this.pictureBox4.Location = new System.Drawing.Point(12, 26);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(89, 84);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            this.pictureBox4.MouseEnter += new System.EventHandler(this.pictureBox4_MouseEnter);
            this.pictureBox4.MouseLeave += new System.EventHandler(this.pictureBox4_MouseLeave);
            // 
            // slot1
            // 
            this.slot1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.slot1.Location = new System.Drawing.Point(158, 151);
            this.slot1.Name = "slot1";
            this.slot1.Size = new System.Drawing.Size(72, 82);
            this.slot1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slot1.TabIndex = 0;
            this.slot1.TabStop = false;
            this.slot1.DragDrop += new System.Windows.Forms.DragEventHandler(this.slot1_DragDrop);
            this.slot1.DragEnter += new System.Windows.Forms.DragEventHandler(this.slot1_DragEnter);
            // 
            // toolbox
            // 
            this.toolbox.Image = global::Concurrent_forms.Properties.Resources.toolbox;
            this.toolbox.Location = new System.Drawing.Point(24, 601);
            this.toolbox.Name = "toolbox";
            this.toolbox.Size = new System.Drawing.Size(453, 116);
            this.toolbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.toolbox.TabIndex = 9;
            this.toolbox.TabStop = false;
            // 
            // infobox
            // 
            this.infobox.Image = global::Concurrent_forms.Properties.Resources.infobox;
            this.infobox.Location = new System.Drawing.Point(766, 12);
            this.infobox.Name = "infobox";
            this.infobox.Size = new System.Drawing.Size(230, 221);
            this.infobox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.infobox.TabIndex = 10;
            this.infobox.TabStop = false;
            // 
            // description
            // 
            this.description.Image = global::Concurrent_forms.Properties.Resources.description;
            this.description.Location = new System.Drawing.Point(782, 239);
            this.description.Name = "description";
            this.description.Size = new System.Drawing.Size(199, 476);
            this.description.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.description.TabIndex = 11;
            this.description.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Concurrent_forms.Properties.Resources.biglogo;
            this.pictureBox1.Location = new System.Drawing.Point(364, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(358, 107);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // infobox_img
            // 
            this.infobox_img.Image = global::Concurrent_forms.Properties.Resources.information;
            this.infobox_img.Location = new System.Drawing.Point(814, 59);
            this.infobox_img.Name = "infobox_img";
            this.infobox_img.Size = new System.Drawing.Size(134, 128);
            this.infobox_img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.infobox_img.TabIndex = 13;
            this.infobox_img.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Concurrent_forms.Properties.Resources.level5;
            this.pictureBox3.Location = new System.Drawing.Point(463, 256);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(300, 199);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Concurrent_forms.Properties.Resources.help_default;
            this.pictureBox2.Location = new System.Drawing.Point(494, 601);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(113, 112);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.MouseEnter += new System.EventHandler(this.pictureBox2_MouseEnter);
            this.pictureBox2.MouseLeave += new System.EventHandler(this.pictureBox2_MouseLeave);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Concurrent_forms.Properties.Resources.level5_2;
            this.pictureBox6.Location = new System.Drawing.Point(12, 125);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(445, 429);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 18;
            this.pictureBox6.TabStop = false;
            // 
            // slot4
            // 
            this.slot4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.slot4.Location = new System.Drawing.Point(260, 300);
            this.slot4.Name = "slot4";
            this.slot4.Size = new System.Drawing.Size(59, 63);
            this.slot4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slot4.TabIndex = 19;
            this.slot4.TabStop = false;
            this.slot4.DragDrop += new System.Windows.Forms.DragEventHandler(this.slot4_DragDrop);
            this.slot4.DragEnter += new System.Windows.Forms.DragEventHandler(this.slot4_DragEnter);
            // 
            // slot5
            // 
            this.slot5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.slot5.Location = new System.Drawing.Point(294, 142);
            this.slot5.Name = "slot5";
            this.slot5.Size = new System.Drawing.Size(58, 63);
            this.slot5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slot5.TabIndex = 20;
            this.slot5.TabStop = false;
            this.slot5.DragDrop += new System.Windows.Forms.DragEventHandler(this.slot5_DragDrop);
            this.slot5.DragEnter += new System.Windows.Forms.DragEventHandler(this.slot5_DragEnter);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Concurrent_forms.Properties.Resources.n_fet;
            this.pictureBox10.Location = new System.Drawing.Point(273, 611);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(89, 92);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 21;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Tag = "inductor_tag";
            this.pictureBox10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox10_MouseDown);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.White;
            this.richTextBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.richTextBox1.Location = new System.Drawing.Point(799, 256);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(165, 434);
            this.richTextBox1.TabIndex = 22;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // nextlvl
            // 
            this.nextlvl.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.nextlvl.Image = global::Concurrent_forms.Properties.Resources.dalej_default;
            this.nextlvl.Location = new System.Drawing.Point(613, 601);
            this.nextlvl.Name = "nextlvl";
            this.nextlvl.Size = new System.Drawing.Size(113, 112);
            this.nextlvl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.nextlvl.TabIndex = 23;
            this.nextlvl.TabStop = false;
            this.nextlvl.Click += new System.EventHandler(this.nextlvl_Click);
            this.nextlvl.MouseEnter += new System.EventHandler(this.nextlvl_MouseEnter);
            this.nextlvl.MouseLeave += new System.EventHandler(this.nextlvl_MouseLeave);
            // 
            // victory
            // 
            this.victory.Image = global::Concurrent_forms.Properties.Resources.gif5;
            this.victory.Location = new System.Drawing.Point(12, 125);
            this.victory.Name = "victory";
            this.victory.Size = new System.Drawing.Size(751, 439);
            this.victory.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.victory.TabIndex = 24;
            this.victory.TabStop = false;
            // 
            // Level5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Concurrent_forms.Properties.Resources.bgcolor;
            this.ClientSize = new System.Drawing.Size(1008, 728);
            this.Controls.Add(this.victory);
            this.Controls.Add(this.slot1);
            this.Controls.Add(this.nextlvl);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.slot5);
            this.Controls.Add(this.slot4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.infobox_img);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.toolbox);
            this.Controls.Add(this.description);
            this.Controls.Add(this.infobox);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox6);
            this.Name = "Level5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Level2";
            this.Load += new System.EventHandler(this.Level5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolbox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infobox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.description)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infobox_img)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slot5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nextlvl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.victory)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        /// <summary>
        /// slot na odpowiedni element
        /// </summary>
        public System.Windows.Forms.PictureBox slot1;
        /// <summary>
        /// przycisk wyjścia do menu głównego
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox4;
        /// <summary>
        /// przycisk sprawdzenia poprawności wyborów
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox5;
        /// <summary>
        /// symbol elementu elektronicznego
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox7;
        /// <summary>
        /// symbol elementu elektronicznego
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox8;
        /// <summary>
        /// symbol elementu elektronicznego
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox9;
        /// <summary>
        /// pictureBox, będący częścią interfejsu graficznego
        /// </summary>
        public System.Windows.Forms.PictureBox toolbox;
        /// <summary>
        /// pictureBox, będący częścią interfejsu graficznego
        /// </summary>
        public System.Windows.Forms.PictureBox infobox;
        /// <summary>
        /// pictureBox, będący częścią interfejsu graficznego
        /// </summary>
        public System.Windows.Forms.PictureBox description;
        /// <summary>
        /// pictureBox, będący częścią interfejsu graficznego
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox1;
        /// <summary>
        /// wyświetlana grafika w polu informacji
        /// </summary>
        public System.Windows.Forms.PictureBox infobox_img;
        /// <summary>
        /// schemat poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox3;
        /// <summary>
        /// przycisk pomocy
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox2;
        /// <summary>
        /// schemat poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox6;
        /// <summary>
        /// slot na odpowiedni element
        /// </summary>
        public System.Windows.Forms.PictureBox slot4;
        /// <summary>
        /// slot na odpowiedni element
        /// </summary>
        public System.Windows.Forms.PictureBox slot5;
        /// <summary>
        /// symbol elementu elektronicznego
        /// </summary>
        public System.Windows.Forms.PictureBox pictureBox10;
        /// <summary>
        /// pole tekstowe z opisami elementów
        /// </summary>
        public System.Windows.Forms.RichTextBox richTextBox1;
        /// <summary>
        /// przycisk przejścia do następnego poziomu
        /// </summary>
        public System.Windows.Forms.PictureBox nextlvl;
        /// <summary>
        /// gif, wyświetlany po wygranej
        /// </summary>
        public System.Windows.Forms.PictureBox victory;
    }
}